package com.omer.a16011110_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;


public class LoginActivity extends AppCompatActivity {
    private EditText userName;
    private EditText password;
    private Button loginButton;
    private int falseLogin=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        userName= (EditText) findViewById(R.id.userName);
        password= (EditText) findViewById(R.id.password);
        loginButton=(Button)findViewById(R.id.btnLogin);
        loginButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if(checkPassword(userName.getText().toString(),password.getText().toString())){
                    Intent mainIntent=new Intent(LoginActivity.this,MainActivity.class);
                    Toast.makeText(LoginActivity.this, "Hoş geldin "+userName.getText().toString()+"", Toast.LENGTH_LONG).show();
                    userName.setText("");
                    password.setText("");
                    startActivity(mainIntent);
                }
                else{
                    falseLogin++;
                    if(falseLogin==3){
                        finish();
                        LoginActivity.super.onDestroy();
                    }

                    Toast.makeText(LoginActivity.this, "Şifreniz veya kullanıcı adınız hatalı. " +(3-falseLogin)+" hakkınız kaldı!", Toast.LENGTH_LONG).show();
                    userName.setText("");
                    password.setText("");

                }
            }
            private boolean checkPassword(String userName, String password) {
                ArrayList<Users> userList= Users.getData();
                for(int i=0;i<userList.size();i++){

                    if(userName.equals(userList.get(i).getUserName()) && password.equals(userList.get(i).getPassword())){
                        return true;
                    }

                }
                 return false;



            }
        });
    }
}
