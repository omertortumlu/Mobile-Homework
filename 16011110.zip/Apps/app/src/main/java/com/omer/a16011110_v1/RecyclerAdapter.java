package com.omer.a16011110_v1;
import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ImageViewHolder>{
    ArrayList<Users> userList=Users.getData();
    LayoutInflater inflater;
    public RecyclerAdapter(Context context,ArrayList<Users> users){
        this.userList=users;
        inflater = LayoutInflater.from(context);
    }
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
         View view= inflater.inflate(R.layout.person_cards,parent,false);
         ImageViewHolder imageViewHolder=new ImageViewHolder(view);
         return imageViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder imageViewHolder, int position) {
        Users us=userList.get(position);
        imageViewHolder.setData(us,position);

    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public static class ImageViewHolder extends RecyclerView.ViewHolder implements  View.OnClickListener{

        ImageView avatar;
        TextView userName;
        TextView password;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            avatar=itemView.findViewById(R.id.avatar);
            userName=itemView.findViewById(R.id.avatarUserName);
            password=itemView.findViewById(R.id.avatarPassword);
        }

        @Override
        public void onClick(View v) {

        }
        public void setData(Users selectedPerson,int position) {
            this.userName.setText("Username: "+selectedPerson.getUserName());
            this.password.setText("Password: "+selectedPerson.getPassword());
            this.avatar.setImageResource(selectedPerson.getImage());
        }
    }
}
