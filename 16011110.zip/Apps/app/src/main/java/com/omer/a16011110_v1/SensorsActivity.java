package com.omer.a16011110_v1;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;



public class SensorsActivity extends AppCompatActivity   {
    private TextView list;
    private SensorManager sensorManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensors);
        try{
            sensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);
            List<Sensor> deviceSensors=sensorManager.getSensorList(Sensor.TYPE_ALL);
            list = findViewById(R.id.sensorList);
            String a ="";
            a+=deviceSensors.size()+" sensors found!\n";

            for(int i=0;i<deviceSensors.size();i++){
                a+=i+1+"-> " + deviceSensors.get(i).getName() + "\n";
            }
            list.setText(a);
        }catch(Exception e){
            Toast.makeText(SensorsActivity.this,"Sensors screen crash!!!" ,Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

    }

}
