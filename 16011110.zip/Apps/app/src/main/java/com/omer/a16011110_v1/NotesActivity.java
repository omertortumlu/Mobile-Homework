package com.omer.a16011110_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class NotesActivity extends AppCompatActivity {
    private EditText subject,note;
    private Button add,update,delete,read;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);
        subject=findViewById(R.id.noteSubject);
        note=findViewById(R.id.note);
        add=findViewById(R.id.addNote);
        update=findViewById(R.id.updateNote);
        delete=findViewById(R.id.deleteNote);
        read=findViewById(R.id.readNote);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=note.getText().toString();
                String file=subject.getText().toString()+".txt";
                try {
                    FileOutputStream fos = openFileOutput(file, Context.MODE_PRIVATE);//Dosyayı Açma Ve Yazma
                    String notes  = note.getText().toString();
                    fos.write(notes.getBytes());
                    fos.close();
                    Toast.makeText(NotesActivity.this,"Note added!!!",Toast.LENGTH_LONG).show();
                }
                catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(NotesActivity.this,"Note didnt add!!!",Toast.LENGTH_LONG).show();
                }
            }
        });
        
        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String file=subject.getText().toString()+".txt";
                try {
                    FileInputStream fis = openFileInput(file);
                    InputStreamReader isr = new InputStreamReader(fis);
                    BufferedReader br = new BufferedReader(isr);
                    note.setText(br.readLine());
                    fis.close();
                    Toast.makeText(NotesActivity.this,"Readed!" ,Toast.LENGTH_LONG).show();


                }
                catch(Exception e){
                    Toast.makeText(NotesActivity.this,"Note don't found!!!" ,Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        });
        
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=note.getText().toString();
                String file=subject.getText().toString()+".txt";
                try {
                    FileOutputStream fos = openFileOutput(file, Context.MODE_PRIVATE);//Dosyayı Açma Ve Yazma
                    String notes  = note.getText().toString();
                    fos.write(notes.getBytes());
                    fos.close();
                    Toast.makeText(NotesActivity.this,"Note updated!!!",Toast.LENGTH_LONG).show();
                }
                catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(NotesActivity.this,"Note didnt update!!!",Toast.LENGTH_LONG).show();
                }
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=note.getText().toString();
                String file=subject.getText().toString()+".txt";
                Context context=null;
                try {
                    FileOutputStream fos = openFileOutput(file, Context.MODE_PRIVATE);//Dosyayı Açma Ve Yazma
                    String notes  = "";
                    note.setText("");
                    subject.setText("");
                    fos.write(notes.getBytes());
                    fos.close();
                    Toast.makeText(NotesActivity.this,"Note deleted!!!",Toast.LENGTH_LONG).show();
                }
                catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(NotesActivity.this,"Note didnt delete!!!",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
