package com.omer.a16011110_v1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class PreferencesActivity extends AppCompatActivity {
    private Switch drk;
    private EditText name,birthday;
    private TextView wei,len,print;
    private RadioButton man,woman;
    private SeekBar weigth,length;
    private Button add,find;
    String drkmod="";
    Bundle bundle;
    Intent intent2;
    Boolean flag;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
            setTheme(R.style.DarkTheme);
            flag=true;
        } else {
            setTheme(R.style.LightTheme);
            flag=false;
        }

        setContentView(R.layout.activity_preferences);
        intent2=getIntent();
        bundle = intent2.getExtras();

        drk=findViewById(R.id.switch1);
        name=(EditText) findViewById(R.id.name);
        wei=findViewById(R.id.wei);
        weigth=findViewById(R.id.seekBarw);
        len=findViewById(R.id.len);
        length=findViewById(R.id.seekBarl);
        man=findViewById(R.id.man);
        woman=findViewById(R.id.woman);
        add=(Button)findViewById(R.id.add);
        find=(Button)findViewById(R.id.find);
        birthday=findViewById(R.id.birthday);
        print=findViewById(R.id.print);
        drk.setChecked(flag);

        weigth.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                wei.setText(Integer.toString(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        length.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                len.setText(Integer.toString(progress));
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences preferences = getSharedPreferences("MY_PREF",MODE_PRIVATE);
                String nm = name.getText().toString();

                String info="";
                String gender="";
                if  (man.isChecked()){gender = "Man";}
                else{gender="Woman";}
                if  (drk.isChecked()){drkmod = "ON";}
                else{drkmod="OFF";}

                SharedPreferences.Editor editor = preferences.edit();
                info = ("Username: " + nm +"\nGender: " + gender + "\nWeight: " + Integer.toString(weigth.getProgress()) +"\nLength: " +Integer.toString(length.getProgress()) + "\nAge: " + birthday.getText().toString() + "\nDark Mod: " + drkmod  );
                editor.putString(nm,info);
                editor.commit();
                Toast.makeText(PreferencesActivity.this,"Information saved",Toast.LENGTH_LONG).show();
            }
        });

        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences preferences = getSharedPreferences("MY_PREF", MODE_PRIVATE);
                String key = name.getText().toString();
                String keyContent = preferences.getString(key, "This name is not found.");
                print.setText(keyContent);

            }
        });



        drk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                }
                chng();
            }
        });


    }
    public void chng(){
        Intent intent=new Intent(PreferencesActivity.this, PreferencesActivity.this.getClass());
        bundle = new Bundle();
        bundle.putString("name",name.getText().toString());
        bundle.putString("wei",wei.getText().toString());
        bundle.putString("len",len.getText().toString());
        bundle.putString("print",print.getText().toString());
        bundle.putBoolean("man",man.isChecked());
        bundle.putBoolean("man",woman.isChecked());
        bundle.putString("birthday",birthday.getText().toString());
        bundle.putBoolean("swc",drk.isChecked());
        intent.putExtras(bundle);
        finish();
        startActivity(intent);
    }
}
