package com.omer.a16011110_v1;

import java.io.Serializable;
import java.util.ArrayList;

public class Users implements Serializable {
    private String userName;
    private String password;
    private int Image;

    public Users(String userName, String password,int Image) {
        this.userName = userName;
        this.password = password;
        this.Image=Image;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }
    public  static ArrayList<Users> getData () {
        ArrayList<Users> userList = new ArrayList<Users>();
        String[] userNames = {"omer", "Mehmet", "Berke", "Pınar", "Çınar", "Cabbar","Koray",};
        String[] passwords = {"1234", "2345", "3456", "4567", "5678", "6789","7890",};
        int Images[] = {R.drawable.a1,R.drawable.a2,R.drawable.a3,R.drawable.a4,R.drawable.a5,R.drawable.a6,R.drawable.a7};
        for (int i = 0; i < userNames.length;i++){
            Users user = new Users(userNames[i],passwords[i],Images[i]);
            userList.add(user);
        }
        return userList;
    }
}
