package com.omer.a16011110_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnmail;
    private Button btnPersons;
    private Button btnPreferences;
    private Button btnSensors;
    private Button btnNotes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnmail=(Button)findViewById(R.id.btnMail);
        btnPersons=(Button)findViewById(R.id.btnPersons);
        btnPreferences=(Button)findViewById(R.id.btnPreferences);
        btnSensors=(Button)findViewById(R.id.btnSensors);
        btnNotes=(Button)findViewById(R.id.btnNotes);

        btnNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent NotesIntent=new Intent(MainActivity.this,NotesActivity.class);
                startActivity(NotesIntent);
            }
        });

        btnmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mailIntent=new Intent(MainActivity.this,MailActivity.class);
                startActivity(mailIntent);
            }
        });

        btnPersons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent personsIntent=new Intent(MainActivity.this,PersonCardsActivity.class);
                startActivity(personsIntent);
            }
        });

        btnPreferences.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent preferencesIntent=new Intent(MainActivity.this,PreferencesActivity.class);
                startActivity(preferencesIntent);
            }
        });

        btnSensors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sensorIntent=new Intent(MainActivity.this, SensorsActivity.class);
                startActivity(sensorIntent);
            }
        });



    }
}
